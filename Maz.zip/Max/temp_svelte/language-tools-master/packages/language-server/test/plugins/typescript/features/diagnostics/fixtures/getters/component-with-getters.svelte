<script>
    export function test() {
        return 1;
    }
    export class Foo {}
    export const bar = true;
</script>
