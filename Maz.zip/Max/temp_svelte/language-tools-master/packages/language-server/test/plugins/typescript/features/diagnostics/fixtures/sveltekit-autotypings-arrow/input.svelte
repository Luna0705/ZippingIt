<script lang="ts">
    import Page from './+page.svelte';
</script>

<Page />
