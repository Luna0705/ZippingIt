module.exports = {
    /**
     * @type {import('svelte/types/compiler/interfaces').CompileOptions}
     */
    compilerOptions: {
        accessors: true
    }
};
