<img>

{#if true}
    <a></a>

    <a
        href=""
    >about</a>
{/if}

<script>
	let value = $state("");

	let x = value;
</script>
