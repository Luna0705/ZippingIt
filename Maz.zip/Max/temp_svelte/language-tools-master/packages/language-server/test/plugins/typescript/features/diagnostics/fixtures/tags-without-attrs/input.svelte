<script lang="ts"></script>

<div></div>
<svg></svg>
<svelte:window></svelte:window>
<svelte:body></svelte:body>
<svelte:head></svelte:head>
