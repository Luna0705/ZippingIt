<script>
    // @ts-check
    export let abc = blubb;
</script>
