<script>
    let a;

    $a
</script>