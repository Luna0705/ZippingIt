<script>class c { b() { return true; } }</script>
<style>
.bla {
c
}
</style>