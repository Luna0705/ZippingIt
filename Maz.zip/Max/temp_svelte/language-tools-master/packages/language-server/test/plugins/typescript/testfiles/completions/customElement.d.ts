declare global {
    namespace svelteHTML {
        interface IntrinsicElements {
            'custom-element': any;
        }
    }
}

export {};