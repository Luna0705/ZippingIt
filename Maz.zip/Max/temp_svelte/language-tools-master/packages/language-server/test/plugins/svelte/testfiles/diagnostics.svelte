<script lang="ts">
    export let name: string;
</script>
