<script>
function a() {
    return null;
}
a().b;
</script>