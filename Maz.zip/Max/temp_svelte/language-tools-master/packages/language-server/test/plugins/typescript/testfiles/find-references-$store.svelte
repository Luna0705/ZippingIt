<script context="module">
    export const findMe = writable('');
</script>

<script>
    if ($findMe) {
        $findMe;
    }
</script>

{$findMe}
