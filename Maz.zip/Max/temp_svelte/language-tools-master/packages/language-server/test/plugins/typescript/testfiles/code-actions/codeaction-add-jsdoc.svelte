<script>
    // @ts-check
    
    export 



    let abc;
    
    let ab;
</script>

{abc}
{ab}
