{#await somePromise catch error}
    <h1>Promise Pending</h1>
{/await}

{#await somePromise 

catch error}
    <h1>Promise Pending</h1>
{/await}