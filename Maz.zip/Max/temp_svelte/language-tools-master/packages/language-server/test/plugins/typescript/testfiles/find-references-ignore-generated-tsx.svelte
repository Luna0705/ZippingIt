<script lang="ts">
  export let foo = false;

  console.log(foo);

</script>

<p>{foo}</p>
