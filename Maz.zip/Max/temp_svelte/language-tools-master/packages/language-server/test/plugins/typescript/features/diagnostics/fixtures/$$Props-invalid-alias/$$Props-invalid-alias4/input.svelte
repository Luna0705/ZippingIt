<script lang="ts">
	type ItemData = {
		x: number;
		y: number;
	}

    type C = ItemData;

	type $$Props = C;

	export let x;
	export let y:string;
</script>
