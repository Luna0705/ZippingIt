<script context="module" lang="ts">
    $: console.log('foo');
</script>
