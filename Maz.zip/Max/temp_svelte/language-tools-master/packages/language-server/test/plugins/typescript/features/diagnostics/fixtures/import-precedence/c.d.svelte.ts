export declare const c: boolean;
