<script>
  import {c} from './c';
  const a = true;
</script>

{c}
<
