<script lang="ts">
	type ItemData = {
		x: number;
		y: number;
	}

	type $$Props =
        ItemData;

	export let x;
	export let y:string;
</script>
