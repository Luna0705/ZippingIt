<script lang="ts">
  import InvalidImport from './doesnt-exist.svelte';
  import ValidImport from './valid-import.svelte';

  InvalidImport;ValidImport;
</script>
