<script></script>

<input {...$$props}>