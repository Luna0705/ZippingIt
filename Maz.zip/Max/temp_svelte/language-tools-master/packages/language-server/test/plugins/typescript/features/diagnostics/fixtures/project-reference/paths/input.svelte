<script lang="ts">
import { hi } from 'hi';

hi((num) => num.toString())

// project reference redirect skip check so put an error here
let a: number = 'a'; a;
</script>
