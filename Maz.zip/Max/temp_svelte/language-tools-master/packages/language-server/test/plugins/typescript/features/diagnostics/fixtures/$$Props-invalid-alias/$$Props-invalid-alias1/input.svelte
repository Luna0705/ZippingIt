<script lang="ts">
	interface ItemData {
		x: number;
		y: number;
	}

	type $$Props =
        ItemData;

	export let x;
	export let y:string;
</script>
