<script lang="ts">
	import { ItemData } from './ItemData'

	type $$Props = ItemData;

	export let x;
	export let y:string;
</script>
