<script lang="ts">
    let a: string | undefined;

    a.
</script>
