<script>
  function whatever() {
    x: {
      console.log('am not reactive');
    }
  }

  whatever();
</script>
