<script>
    export let foo = true;
</script>