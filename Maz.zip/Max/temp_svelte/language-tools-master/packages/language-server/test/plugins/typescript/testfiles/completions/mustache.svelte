<script>
    let a = 1;
    let b = { b: 1 };
</script>
{a?.}
{b.}
