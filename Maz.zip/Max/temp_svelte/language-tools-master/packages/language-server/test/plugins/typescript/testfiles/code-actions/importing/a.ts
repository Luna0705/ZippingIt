import type { Writable } from 'svelte/store';

export const someStore = null as any as Writable<number>;
