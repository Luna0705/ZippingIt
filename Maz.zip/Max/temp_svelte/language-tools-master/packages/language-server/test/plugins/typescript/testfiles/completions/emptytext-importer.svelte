<script>
	import Button from './emptytext-imported.svelte';
</script>

<Button size="" />
