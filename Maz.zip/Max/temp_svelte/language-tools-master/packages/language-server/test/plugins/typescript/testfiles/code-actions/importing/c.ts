import type { SvelteComponentTyped as tmp } from 'svelte';

const SvelteComponentTyped: typeof tmp = null as any;

export class FixAllImported3 extends SvelteComponentTyped {}
