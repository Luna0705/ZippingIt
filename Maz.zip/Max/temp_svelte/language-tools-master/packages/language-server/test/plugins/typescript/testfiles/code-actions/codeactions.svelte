<script lang="ts">
import {C} from 'blubb';
import {B} from 'bla';
import {A} from 'bla';
import {D} from 'd';

let a = true;
A;C;
let b = Math.random() > 0.5 ? true : false;
abc();
</script>
{abc()}
<Empty />
<button on:click={e => handleClick(e)} />