<script lang="ts">
    interface $$Events {
        a: CustomEvent<boolean>;
        /**
         * TEST
         ```ts
         const abc: boolean = true;
         ```
         */
        abc: MouseEvent;
        c;
    }
</script>