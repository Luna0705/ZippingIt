<script></script>

<input {...$$restProps}>