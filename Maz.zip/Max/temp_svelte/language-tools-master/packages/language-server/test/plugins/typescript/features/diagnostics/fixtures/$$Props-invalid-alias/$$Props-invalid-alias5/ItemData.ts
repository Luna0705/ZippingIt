export type ItemData = {
    x: number;
    y: number;
};
