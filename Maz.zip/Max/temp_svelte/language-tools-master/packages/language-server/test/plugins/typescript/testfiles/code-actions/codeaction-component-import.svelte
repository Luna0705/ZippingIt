<script lang="ts">
    class EMpty {}
</script>

<Empty />