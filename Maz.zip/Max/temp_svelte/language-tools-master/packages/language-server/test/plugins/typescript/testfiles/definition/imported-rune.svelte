<script lang="ts">
    let {} = $props();
</script>