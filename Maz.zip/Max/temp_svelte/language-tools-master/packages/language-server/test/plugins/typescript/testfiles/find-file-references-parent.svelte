<script>
import FindFileReferencesChild from "./find-file-references-child.svelte";

    const findMe = true;
    if (findMe) {
        findMe;
    }
</script>

<FindFileReferencesChild></FindFileReferencesChild>
