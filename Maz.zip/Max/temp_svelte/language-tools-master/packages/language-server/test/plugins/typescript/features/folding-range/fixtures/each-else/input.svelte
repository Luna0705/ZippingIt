{#each items as item}
    {item}
{:else}
    no items
{/each}