<script>
    /***/
    let a;

    /***/
    function abc(parameter1) {

    }
</script>
