<script>
    import { ComponentDef, ComponentDef2 } from './ComponentDef';
</script>

<ComponentDef on></ComponentDef>
<ComponentDef let></ComponentDef>
<ComponentDef2 on></ComponentDef2>
