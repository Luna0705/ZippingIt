<script lang="ts">
    export let required: string;
    export let optional1 = '';
    export let optional2: string | undefined = undefined;
</script>
