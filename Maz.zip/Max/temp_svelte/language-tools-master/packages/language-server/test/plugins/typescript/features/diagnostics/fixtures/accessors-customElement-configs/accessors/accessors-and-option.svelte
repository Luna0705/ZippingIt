<script lang="ts">
    export let abc = 1;
</script>
<svelte:options accessors={false} />