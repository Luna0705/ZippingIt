<script lang="ts">
    abc('@');

    function abc(str: 'hi' | '@hi' | '~hi') {}
</script>