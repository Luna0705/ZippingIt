<script lang="ts">
    import { ScndImport } from "./to-import";
    ScndImpor
</script>