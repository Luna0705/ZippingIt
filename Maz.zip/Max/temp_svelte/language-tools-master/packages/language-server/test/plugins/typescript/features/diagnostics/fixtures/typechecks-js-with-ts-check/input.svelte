<script>
//@ts-check
const asd = 1;
asd.bla;
</script>