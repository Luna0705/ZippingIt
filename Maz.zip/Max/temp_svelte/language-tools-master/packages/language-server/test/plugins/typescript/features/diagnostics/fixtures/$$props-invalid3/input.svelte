<script lang="ts">
	interface $$Props {
		exported1: boolean;
	}

	export let wrong: boolean;
</script>
