<script script lang="ts">
  import Component1 from "./find-component-references-child.svelte";
</script>
