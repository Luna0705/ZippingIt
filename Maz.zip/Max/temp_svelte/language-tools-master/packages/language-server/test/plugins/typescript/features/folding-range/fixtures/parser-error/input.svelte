<script lang="ts">
    function hi() {

    }
</script>

{#if 'hi'}
    <div></div>
{:else}
    <div></div>
{/if
