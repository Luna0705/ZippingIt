<script lang="ts">
	interface $$Props {
		exported1: boolean;
	}

	export let exported1 = 'wrong type'
</script>
