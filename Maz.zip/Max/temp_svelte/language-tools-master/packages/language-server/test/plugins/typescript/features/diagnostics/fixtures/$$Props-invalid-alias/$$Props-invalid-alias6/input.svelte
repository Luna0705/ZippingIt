<script lang="ts">
	import { ItemData as ItemData2 } from './ItemData'

	type $$Props = ItemData2;

	export let x;
	export let y:string;
</script>
