<script lang="ts">
    interface Foo {
        bar: string;
    }

    let foo: Foo = { bar: 'baz' };
</script>