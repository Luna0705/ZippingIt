<script lang="ts">
    $someOtherStore;
    $someStore;
</script>
