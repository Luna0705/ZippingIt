<script lang="ts">
    interface A {
        b: boolean;
    }
    const a: A = { b: true };
</script>

<img>

{#if true}
    <a></a>

    <a
        href=""
    >about</a>
{/if}
