<script lang="ts">
    interface $$Events {
        aa: CustomEvent<boolean>;
        /**
         * TEST
         */
        ab: MouseEvent;
        ac;
    }
</script>