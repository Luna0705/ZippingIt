import { SvelteComponentTyped } from 'svelte';

export class Component extends SvelteComponentTyped<{ prop: number }> {}
