<script lang="ts">
    export let data;
</script>
