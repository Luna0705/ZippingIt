<script lang="ts">
    import { formatDate } from './util';

    formatDate(new Date())
</script>