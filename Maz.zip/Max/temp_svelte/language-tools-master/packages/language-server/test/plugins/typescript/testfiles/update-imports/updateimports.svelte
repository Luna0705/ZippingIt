<script>
import Bla from './imported.svelte';
</script>
