<script lang="ts">
  let items = [1]
</script>

{#each items as item, i}
  {item}
{/each}