<script lang="ts">
  import B from './B';
  import A from './A';

  type T = $$Generic;
  export let t: T;
</script>

<A>{c}</A>