module.exports = {
    /**
     * @type {import('svelte/types/compiler/interfaces').CompileOptions}
     */
    compilerOptions: {
        customElement: true
    }
};
