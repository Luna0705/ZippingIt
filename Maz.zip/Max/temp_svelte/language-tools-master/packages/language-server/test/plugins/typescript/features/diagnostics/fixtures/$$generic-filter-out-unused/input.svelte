<script lang="ts">
    // The "is unused" hint will appear at the script tag
    // So we rather filter out the hint completely
    type T = $$Generic;
</script>
