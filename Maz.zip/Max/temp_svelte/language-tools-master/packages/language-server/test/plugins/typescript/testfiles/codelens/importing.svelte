<script>
    import References from "./references.svelte";

</script>
<References></References>