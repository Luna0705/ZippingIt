<script context="module" lang="ts">
  let unsuedVar: undefined;
</script>

<script lang="ts">
  export let unused1 = true;
  export let unused2 = true;
</script>
