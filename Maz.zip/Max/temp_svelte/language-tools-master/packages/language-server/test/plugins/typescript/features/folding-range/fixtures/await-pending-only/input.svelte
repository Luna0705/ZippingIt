{#await somePromise}
    <h1>Loading</h1>
{/await}