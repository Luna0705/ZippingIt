<script context="module">
    // @ts-check
    let a = 1;
    a = ''
</script>
