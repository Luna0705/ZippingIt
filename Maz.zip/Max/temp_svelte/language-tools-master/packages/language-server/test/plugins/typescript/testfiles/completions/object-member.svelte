<script lang="ts">
    interface SayHi {
        hi(name: string): string
    }

    const a: SayHi = {
        h
    }

    class A implements SayHi {
        h
    }
</script>