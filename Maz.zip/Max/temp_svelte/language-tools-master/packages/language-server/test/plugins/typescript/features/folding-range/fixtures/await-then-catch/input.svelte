{#await Promise.resolve() then value}
    {value}
{:catch error}
    {error}
{/await}