<page>
    <label class="info" horizontalAlignment="center" verticalAlignment="center" textWrap="true">
        <formattedString>
            <span class="fas" text="&#xf135;" />
            <span text=" {message}" />
        </formattedString>
    </label>
    <div asd="" />
</page>

<script lang="ts">
    let message: string = "Blank Svelte Native App"
</script>
