<script lang="ts">
	interface $$Props {
		exported1?: string;
	}

	export let exported1: string;
</script>
