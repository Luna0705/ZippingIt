<script lang="ts">
    import { a } from './a.svelte';
    import B from './b.svelte';
    import { b } from './b.svelte.js';
    import { c } from './c.svelte';
    import D from './d.svelte';
    import { d } from './d.svelte.js';
    a;
    b;
    c;
    d;
</script>

<B />
<D />
