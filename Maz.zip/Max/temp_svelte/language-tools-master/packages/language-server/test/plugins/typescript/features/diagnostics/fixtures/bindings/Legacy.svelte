<script lang="ts">
    export let value = 'implicitly bindable';
    export function bind_and_prop() {
        return true;
    }
</script>
