<script>
    import { hi } from './declaration-map-project/types'
</script>