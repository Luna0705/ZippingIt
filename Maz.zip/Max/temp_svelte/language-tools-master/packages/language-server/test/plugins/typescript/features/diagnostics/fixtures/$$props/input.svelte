<script lang="ts">
    import Props from "./$$props.svelte";
</script>

<Props class="abc"></Props>
