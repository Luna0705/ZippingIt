<script lang="ts">
	export let size: 's' | 'm' | 'l';
</script>
