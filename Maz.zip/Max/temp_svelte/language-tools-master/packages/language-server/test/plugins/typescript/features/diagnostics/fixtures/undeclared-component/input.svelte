<script lang="ts"></script>

<Component />
<SomeLongComponentName />