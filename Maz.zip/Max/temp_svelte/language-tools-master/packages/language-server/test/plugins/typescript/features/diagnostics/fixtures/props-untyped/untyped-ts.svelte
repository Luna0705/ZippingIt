<script lang="ts">
    export let untyped;
    export let typedAsAny: any;
</script>