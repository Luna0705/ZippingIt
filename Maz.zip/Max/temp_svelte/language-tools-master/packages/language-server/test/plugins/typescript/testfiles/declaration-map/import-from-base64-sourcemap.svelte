<script>
    import { hi } from './declaration-map-project/types/base64'
</script>