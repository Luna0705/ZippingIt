<script lang="ts">
    import { longLongName2 } from './imported'
    function longLongName() {
    }
</script>

<Component></Component>

{#each [''] as longLongName4}
    {longLongName4}
{/each}}