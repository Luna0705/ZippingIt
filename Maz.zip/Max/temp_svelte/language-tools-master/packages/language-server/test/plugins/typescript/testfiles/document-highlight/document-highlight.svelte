<script>
    let prop = 1;

    if (prop) {

    }
</script>

{prop}