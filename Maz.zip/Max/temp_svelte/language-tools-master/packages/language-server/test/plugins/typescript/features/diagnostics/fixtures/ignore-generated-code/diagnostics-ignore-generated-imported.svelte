<script lang="ts">
  export let variant: "foo" | "bar";
  export let style: string;
</script>