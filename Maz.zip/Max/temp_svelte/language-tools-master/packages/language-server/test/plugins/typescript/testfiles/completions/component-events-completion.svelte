<script lang="ts">
    import CEI from './component-events-interface.svelte';
    import CED from './component-events-event-dispatcher.svelte';
</script>

<CEI   on:a foo="" />
<CED   on />
