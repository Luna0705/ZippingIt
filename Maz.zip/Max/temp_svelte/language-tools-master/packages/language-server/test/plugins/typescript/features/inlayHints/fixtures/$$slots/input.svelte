<script></script>

{#if $$slots.default}
    <div><slot></slot></div>
{/if}