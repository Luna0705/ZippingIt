<script lang="ts">
    let { foo }: {
        foo: import('svelte').Snippet<[a: '']>
        children?: import('svelte').Snippet
        required: import('svelte').Snippet
    } = $props();
</script>