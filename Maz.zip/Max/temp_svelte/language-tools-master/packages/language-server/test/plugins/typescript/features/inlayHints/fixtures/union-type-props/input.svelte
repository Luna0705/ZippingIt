<script lang="ts">
    export let a: number | string = 1;
</script>