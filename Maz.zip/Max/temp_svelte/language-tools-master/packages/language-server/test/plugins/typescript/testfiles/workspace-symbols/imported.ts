/**
 * @deprecated
 */
export interface longLongName2 {
    longLongName3: string;
}