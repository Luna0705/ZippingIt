<div class={$$props.class}></div>
