<script lang="ts">
    let number = 1;
</script>