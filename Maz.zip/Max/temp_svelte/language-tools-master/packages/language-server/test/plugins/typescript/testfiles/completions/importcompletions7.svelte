<script context="module">

</script>

<script>
	import * as data from "./to-import";

	Compon
</script>
