export declare function hi(): void;
//# sourceMappingURL=index.d.ts.map