<script lang="ts">
    export let abc = 1;
</script>