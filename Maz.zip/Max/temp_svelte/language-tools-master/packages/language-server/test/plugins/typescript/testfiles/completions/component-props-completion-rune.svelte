<script lang="ts">
    import ComponentPropsRune from './component-props-rune.svelte'
    import { ComponentDef5 } from './ComponentDef'
</script>

<ComponentPropsRune />
<ComponentDef5 />
