{#snippet hi2(a = 1)}
    hello world
{/snippet}

{@render hi2(1)}