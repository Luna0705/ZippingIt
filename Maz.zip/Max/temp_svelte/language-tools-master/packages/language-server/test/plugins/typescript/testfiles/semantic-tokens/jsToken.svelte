<script>
    console.log();
</script>
