<script context="module">
  import {c} from './c';
  const a = true;
</script>

{c}
