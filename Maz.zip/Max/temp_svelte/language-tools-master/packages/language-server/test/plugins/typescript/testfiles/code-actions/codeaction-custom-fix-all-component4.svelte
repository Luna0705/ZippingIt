<script lang="ts">
class FixAllImported3 {}
</script>

<FixAllImported />
<FixAllImported2 />
