<script lang="ts">
    class A {
        b = 1
    }
</script>