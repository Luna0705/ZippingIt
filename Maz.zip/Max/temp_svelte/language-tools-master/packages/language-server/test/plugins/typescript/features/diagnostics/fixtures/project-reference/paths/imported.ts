/**
 *
 * @param cb callback because if the module resolution failed there will be a noImplicitAny error
 */
export function hi(cb: (num: number) => string) {}
