{#key hi}
    {hi}
{/key}

{#key 

hi}
    {hi}
{/key}