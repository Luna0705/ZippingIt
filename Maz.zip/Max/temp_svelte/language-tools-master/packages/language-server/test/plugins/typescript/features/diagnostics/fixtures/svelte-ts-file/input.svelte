<script lang="ts">
  import { bar } from './foo.svelte';
  bar;
</script>
