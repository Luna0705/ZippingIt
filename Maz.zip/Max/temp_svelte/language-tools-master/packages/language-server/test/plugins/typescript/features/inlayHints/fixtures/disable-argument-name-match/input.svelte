<script lang="ts">
    function log(message: string) {
    }

    let message: string = 'Hello World';
    log(message);
</script>