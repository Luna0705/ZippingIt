<script lang="ts">
    import { foo } from './shared-comp.svelte';
    import { bar } from './shared-ts-file';
    foo;bar;
</script>
