<script lang="ts">
  let abc = "";
</script>

a
<div>a
a</div>
<div></div>
<Comp>a
a</Comp>
<Comp></Comp>
