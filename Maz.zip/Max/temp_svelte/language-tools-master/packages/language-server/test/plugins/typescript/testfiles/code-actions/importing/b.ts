import type { Readable, Writable } from 'svelte/store';

export const someStore = null as any as Readable<number>;
export const someOtherStore = null as any as Writable<number>;
