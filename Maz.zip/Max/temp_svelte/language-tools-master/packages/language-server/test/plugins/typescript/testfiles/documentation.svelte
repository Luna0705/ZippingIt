<script lang="ts">
    import { foo } from './documentation'

    fo
</script>
