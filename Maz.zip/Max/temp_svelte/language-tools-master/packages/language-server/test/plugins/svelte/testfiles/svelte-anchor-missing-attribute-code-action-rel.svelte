<a href="https://svelte.dev" target="_blank" rel="noopener">Svelte</a>
