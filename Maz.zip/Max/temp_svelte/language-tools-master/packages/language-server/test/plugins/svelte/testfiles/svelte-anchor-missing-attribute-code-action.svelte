<a href="https://svelte.dev" target="_blank">Svelte</a>
