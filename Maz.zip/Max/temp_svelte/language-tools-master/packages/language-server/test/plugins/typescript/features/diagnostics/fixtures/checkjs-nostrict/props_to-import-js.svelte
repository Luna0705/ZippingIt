<script>
  /**
   * @type {string}
   */
  export let required;
  export let optional1 = '';
  /**
   * @type {string | undefined}
   */
  export let optional2 = undefined;
</script>
