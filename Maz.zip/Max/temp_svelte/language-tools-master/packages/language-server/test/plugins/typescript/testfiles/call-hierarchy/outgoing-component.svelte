<script lang="ts">
    import AnotherRefFormatDate from './another-ref-format-date.svelte';    

    function hi() {
        log('hi')
    }

    function log(msg: string) {}
</script>

<AnotherRefFormatDate />