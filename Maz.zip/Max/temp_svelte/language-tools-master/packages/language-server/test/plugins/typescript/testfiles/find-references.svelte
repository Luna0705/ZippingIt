<script>
    const findMe = true;
    if (findMe) {
        findMe;
    }
</script>
