<script lang="ts">
    import ImportedRune from './imported-rune.svelte';
</script>

<ImportedRune></ImportedRune>