<script context="module">
  import {c} from './c';
  import {d} from './d';
  const a = true;
</script>

{c}{d}
