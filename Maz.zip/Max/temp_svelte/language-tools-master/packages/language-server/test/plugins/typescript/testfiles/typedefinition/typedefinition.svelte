<script lang="ts">
    import { SomeImportedClass } from './some-class';

    class SomeClass {}

    let someClassInstance1 = new SomeImportedClass();
    let someClassInstance2 = new SomeClass();
</script>
