<script lang="ts">
    $: hi = 1;
</script>