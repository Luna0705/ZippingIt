<script context="module">
  import {c} from './c';
  // do whatever
</script>

<script lang="ts">
  import B from './B';
  import A from './A';
</script>

<A>{c}</A>