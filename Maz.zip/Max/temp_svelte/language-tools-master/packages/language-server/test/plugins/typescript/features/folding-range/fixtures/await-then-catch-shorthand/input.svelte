{#await Promise.resolve() then value}
    {value}
{:catch}
    error
{/await}