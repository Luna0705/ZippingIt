<script>
    {
        await Promise.resolve()
    }

    function test() {
        await Promise.resolve()
    }
</script>