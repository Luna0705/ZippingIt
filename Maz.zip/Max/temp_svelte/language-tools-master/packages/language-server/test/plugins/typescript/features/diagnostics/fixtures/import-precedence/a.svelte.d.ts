export declare const a: boolean;
