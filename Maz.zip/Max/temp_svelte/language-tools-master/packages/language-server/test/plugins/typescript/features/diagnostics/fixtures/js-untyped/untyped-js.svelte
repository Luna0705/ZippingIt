<script>
    export let untyped;
</script>

<slot {untyped} />