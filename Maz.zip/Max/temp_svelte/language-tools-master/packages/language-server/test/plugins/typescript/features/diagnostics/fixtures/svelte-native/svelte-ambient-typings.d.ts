declare namespace svelteNative {
    function createElement(element: string, attrs: any): any;
    function mapElementTag(tag: any): any;
}
