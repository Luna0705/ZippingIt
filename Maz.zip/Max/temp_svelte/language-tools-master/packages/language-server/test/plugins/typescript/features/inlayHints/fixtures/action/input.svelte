<script>
    function action(ele, p) { }
</script>

<button use:action></button>
<button use:action={{ p: 1 }}></button>