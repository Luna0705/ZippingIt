<script lang="ts">
    /**@deprecated*/
    let a;
    a;
    let c;
</script>
