{#each items as item}
    {item}
{/each}

{#each items as 
    item}
    {item}
{/each}
