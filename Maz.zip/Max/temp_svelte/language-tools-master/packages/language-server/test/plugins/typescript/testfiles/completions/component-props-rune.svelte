<script lang="ts">
    let { a }: { a: string } = $props();
</script>
