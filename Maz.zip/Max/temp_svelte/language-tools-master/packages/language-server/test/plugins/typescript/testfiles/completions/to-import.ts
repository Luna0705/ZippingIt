import type { Writable } from 'svelte/store';

export class ScndImport {}

export const store = null as any as Writable<number>;
