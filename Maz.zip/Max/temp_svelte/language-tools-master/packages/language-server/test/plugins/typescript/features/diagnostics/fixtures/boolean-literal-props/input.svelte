<script lang="ts">
    import Component from './Component.svelte'
</script>

<Component flag />
