{#each items as 
{id}
(id)}
    {id}
{/each}
