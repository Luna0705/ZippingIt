<script>
    import { } from './t.png'
    // @ts-ignore
    import { } from './somepng.png'
</script>
